import UIKit

var paperCollection : [String] = []
paperCollection += ["Brown Paper", "Tissue Paper", "Wrapping Paper", "Construction Paper", "Cardstock", "Watercolor Paper", "Thicker Watercolor Paper", "Tracing Paper", "Sketching Paper"]

for item in paperCollection {
    print(item)
}
